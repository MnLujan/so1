var searchData=
[
  ['get_5fdiskstas',['get_diskstas',['../_l_a_b1_8h.html#a31490ddf4af19359835f3c1f7fa5a1ae',1,'LAB1.h']]],
  ['get_5finfo_5fcpu',['get_info_CPU',['../_l_a_b1_8h.html#a2678c9173bf4f107f29739b8ff5a2ef5',1,'LAB1.h']]],
  ['get_5fmemory',['get_memory',['../_l_a_b1_8h.html#a31a53abacd241ba399a5498681ccbb90',1,'LAB1.h']]],
  ['get_5fnum_5ffs',['get_Num_FS',['../_l_a_b1_8h.html#a20966986b0f16b5229e08d9b09177f43',1,'LAB1.h']]],
  ['get_5fprocess',['get_process',['../_l_a_b1_8h.html#ab12e2f54a44db317660aa7328dee6045',1,'LAB1.h']]],
  ['get_5ftime',['get_time',['../_l_a_b1_8h.html#a95b597240cd38d7a44e484abfccb74d1',1,'LAB1.h']]],
  ['get_5fuptime',['get_uptime',['../_l_a_b1_8h.html#a0024bbfc11cdcced46a020294ba258b2',1,'LAB1.h']]],
  ['get_5fv_5fkernel',['get_v_kernel',['../_l_a_b1_8h.html#a77144d99cd85a12b3992ca5faf96b61d',1,'LAB1.h']]]
];
