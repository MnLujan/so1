var searchData=
[
  ['buffer',['buffer',['../_l_a_b1_8h.html#a49419ac56caa29bba4285db6a032516b',1,'LAB1.h']]],
  ['buffersize',['BUFFERSIZE',['../_l_a_b1_8h.html#ac3146f1e9227301bb4aa518f4d336cee',1,'LAB1.h']]]
];
