var searchData=
[
  ['loadavg',['LoadAvg',['../_l_a_b1_8h.html#a4cb0786fda2902b2e2cf200012efc10d',1,'LAB1.h']]]
];
