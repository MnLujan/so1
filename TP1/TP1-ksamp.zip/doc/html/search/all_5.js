var searchData=
[
  ['printincio',['printincio',['../_l_a_b1_8h.html#a3f585c2fb319d1cc146c50d9dc7e8ecc',1,'LAB1.h']]],
  ['process',['Process',['../_l_a_b1_8h.html#adc95ed7b2ed00267008a4582165481f7',1,'LAB1.h']]]
];
